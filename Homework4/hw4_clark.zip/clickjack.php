<?php
	if(isset($_SESSION['login'])){
		print_r($_SESSION);
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Eyyyy</title>
</head>
<body>

<div style="position: absolute; left: 10px; top: 10px;">
	Hey - we're giving away iPad minis!!! Just click the WIN button and it's yours!!!
</div>  
<div style="position: absolute; left: 200px; top: 50px;">
  <img src="ipad.jpg"; width="250">
</div>
<div style="position: absolute; left: 1050px; top: 260px; color: red; font-weight: bold;">
	WIN
</div>
<iframe src="http://54.84.187.188/armbook/home.php?id=60" name="iframe_a" style="opacity: 0.5; height: 100vh; width: 100%;"></iframe>
</body>
</html>
